
<?php $__env->startSection('content'); ?>
      <div class="form-login w-100 m-auto">
        <form action="<?php echo e(route('uploadmethod')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <h1 class="title-login">UPLOAD YOUR IMAGE</h1>
          <?php if(session('status') && session('status') == 'success'): ?>
            <div class="form-group">
              <label class="success_msg">Image Uploaded</label>
            </div>
          <?php endif; ?>
          <div class="groupinp">
            <p>UPLOAD IMAGE</p>
            <img id="previmg" class="prev" />
            <div id="inputfile">
              <input id="upfile" name="imginput" type="file" value="upload" onchange="fileInputRep(this)" />
            </div>
            <div id="btn-file" class="btn-file" name="img">CHOOSE FILE</div>
          </div>
          <div class="groupinp">
              <p>TITLE</p>
              <input type="text" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="title" placeholder="IMAGE TITLE" value="<?php echo e(old('title')); ?>">
          </div>
          <div class="groupinp">
              <p>DESCRIPTION</p>
              <input type="text" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="description" placeholder="IMAGE DESCRIPTION" value="<?php echo e(old('description')); ?>">
          </div>
          <button class="w-100 btn btn-lg sub" type="submit">UPLOAD</button>
        </form>
      </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customJS'); ?>
<script src="/assets/js/form.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/upload.blade.php ENDPATH**/ ?>