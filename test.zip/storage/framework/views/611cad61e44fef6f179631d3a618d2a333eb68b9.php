<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Developer Test</title>
        <link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="/assets/fontawesome/css/all.min.css" rel="stylesheet">
        <link href="/assets/css/styles.css" rel="stylesheet">
    </head>
    <body>
      <nav id="menu" class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="/">Developer Test</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nvmenu" aria-controls="nvmenu" aria-expanded="false" aria-label="Toggle Menu">
            <span class="navbar-toggler-icon"></span>
          </button>
            <div class="collapse navbar-collapse" id="nvmenu">
              <ul class="navbar-nav ms-auto">

                <?php if(SESSION('ID_User') != ''): ?>
                <li class="nav-item">
                  <a class="nav-link user-mail"><?php echo e(SESSION('tst_email')); ?></a>
                </li>
                <?php endif; ?>
                <?php if(SESSION('tst_role') == 1): ?>
                <li class="nav-item">
                  <a href="<?php echo e(route('moderation')); ?>" class="nav-link btn-fav"> Moderation</a>
                </li>
                <?php endif; ?>
                <li class="nav-item">
                  <a href="<?php echo e(route('favorites')); ?>" class="nav-link btn-fav"><i class="fa-solid fa-heart"></i> Favorites</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('upload')); ?>" class="nav-link btn-upload">Upload</a>
                </li>
                <?php if(SESSION('ID_User') != ''): ?>
                <li class="nav-item">
                  <a href="<?php echo e(route('logout')); ?>" class="nav-link btn-login">Logout</a>
                </li>
                <?php else: ?>
                <li class="nav-item">
                  <a href="<?php echo e(route('login')); ?>" class="nav-link btn-login">Login</a>
                </li>
                <?php endif; ?>
              </ul>
            </div>
        </div>
      </nav>
      <?php echo $__env->yieldContent('content'); ?>
    </body>
    <script src="/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script async src="/assets/js/masonry.min.js"></script>
    <script href="/assets/fontawesome/js/all.min.js"></script>
    <?php echo $__env->yieldContent('customJS'); ?>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">

          <div class="modal-body">
            <div class="modal-header">
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="row">
              <div class="col-12">
                <img id="imgprev" />
              </div>
              <div class="col-12">
                <h5 id="descTitle" class="card-title"></h5>
                <p id="descmod">

                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
</html>
<?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/template.blade.php ENDPATH**/ ?>