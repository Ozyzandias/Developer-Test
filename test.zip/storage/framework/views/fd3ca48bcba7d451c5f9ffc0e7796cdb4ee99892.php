<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>
        <link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="/assets/fontawesome/css/all.min.css" rel="stylesheet">
        <link href="/assets/css/styles.css" rel="stylesheet">
    </head>
    <body>
      <nav id="menu" class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Developer Test</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nvmenu" aria-controls="nvmenu" aria-expanded="false" aria-label="Toggle Menu">
            <span class="navbar-toggler-icon"></span>
          </button>
            <div class="collapse navbar-collapse" id="nvmenu">
              <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                  <a class="nav-link btn-fav"><i class="fa-solid fa-heart"></i> Favorites</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link btn-upload">Upload</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link btn-login">Login</a>
                </li>
              </ul>
            </div>
        </div>
      </nav>
      <div class="container-fluid">
        <div id="content" class="row" data-masonry='{"percentPosition": true }'>
          <div class="col-sm-6 col-md-4 col-lg-2 mb-4">
            <div class="card">
              <img src="https://scontent.fqro1-1.fna.fbcdn.net/v/t39.30808-6/312221673_697822048371053_1149442349994835333_n.jpg?stp=dst-jpg_p526x296&_nc_cat=105&ccb=1-7&_nc_sid=8bfeb9&_nc_ohc=2yctMYOK32wAX_GO9Yi&_nc_ht=scontent.fqro1-1.fna&oh=00_AfDXznU3LKvnV1HQHGlBQsOpBxiJ7nzAD8yMF2hCooj_Pg&oe=63612AAC" />
              <div class="card-body">
                <h5 class="card-title">Card title that wraps to a new line</h5>
                <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </body>
    <script src="/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script async src="/assets/js/masonry.min.js"></script>
    <script href="/assets/fontawesome/js/all.min.js"></script>
</html>
<?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/welcome.blade.php ENDPATH**/ ?>