
<?php $__env->startSection('content'); ?>

  <div class="container-fluid">
    <h2 class="modtitle">IMAGE MODETARION</h1>
    <div id="content" class="row" data-masonry='{"percentPosition": true }'>
      <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-sm-6 col-md-4 col-lg-2 mb-4">
        <div class="card" id="<?php echo e($img->ID_Image); ?>">
          <img id="<?php echo e($img->ID_Image); ?>-img" src="/<?php echo e($img->tst_name); ?>" />
          <div class="card-body">
            <h5 id="<?php echo e($img->ID_Image); ?>-title" class="card-title"><?php echo e($img->tst_Title); ?></h5>
            <p id="<?php echo e($img->ID_Image); ?>-desc" class="card-text"><?php echo e($img->tst_Description); ?></p>
            <a href="/moderation/approve/<?php echo e($img->ID_Image); ?>" class="btn allow" id="<?php echo e($img->ID_Image); ?>">ALLOW</a>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('customJS'); ?>
<script src="/assets/js/main.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/moderation.blade.php ENDPATH**/ ?>