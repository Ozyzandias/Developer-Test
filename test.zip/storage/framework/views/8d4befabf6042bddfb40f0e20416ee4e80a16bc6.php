
<?php $__env->startSection('content'); ?>
<div class="form-login w-100 m-auto">
  <form action="<?php echo e(route('signmethod')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h1 class="title-login">LOGIN</h1>
    <div class="btn-group selector">
      <a href="<?php echo e(route('login')); ?>" class="btn active" aria-current="page">SIGN IN</a>
      <a href="<?php echo e(route('signup')); ?>" class="btn">SIGN UP</a>
    </div>
    <?php if(session('error') && session('error') == 'not_found'): ?>
      <div class="form-group">
        <label class="error_msg">User not found.</label>
      </div>
    <?php endif; ?>
    <div class="groupinp">
        <p>EMAIL</p>
        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name ="email" id="email" placeholder="YOUR EMAIL" value="<?php echo e(old('email')); ?>">
    </div>
    <div class="groupinp">
        <p>PASSWORD</p>
        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="************" value="<?php echo e(old('password')); ?>">
    </div>
    <button class="w-100 btn btn-lg sub" type="submit">Sign in</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/signin.blade.php ENDPATH**/ ?>