<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Developer Test</title>
        <link href="/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="/assets/fontawesome/css/all.min.css" rel="stylesheet">
        <link href="/assets/css/styles.css" rel="stylesheet">
    </head>
    <body>
      <nav id="menu" class="navbar navbar-expand-lg sticky-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">Developer Test</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nvmenu" aria-controls="nvmenu" aria-expanded="false" aria-label="Toggle Menu">
            <span class="navbar-toggler-icon"></span>
          </button>
            <div class="collapse navbar-collapse" id="nvmenu">
              <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                  <a class="nav-link btn-fav"><i class="fa-solid fa-heart"></i> Favorites</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link btn-upload">Upload</a>
                </li>
                <li class="nav-item">
                  <a href="<?php echo e(route('login')); ?>" class="nav-link btn-login">Login</a>
                </li>
              </ul>
            </div>
        </div>
      </nav>
      <div class="form-login w-100 m-auto">
        <form>
          <h1 class="title-login">LOGIN</h1>
          <div class="btn-group selector">
            <a href="<?php echo e(route('login')); ?>" class="btn" aria-current="page">SIGN IN</a>
            <a href="<?php echo e(route('signup')); ?>" class="btn active">SIGN UP</a>
          </div>
          <div class="groupinp">
              <p>EMAIL</p>
              <input type="email" class="form-control" id="user" placeholder="YOUR EMAIL">
          </div>
          <div class="groupinp">
              <p>PASSWORD</p>
              <input type="password" class="form-control" id="password" placeholder="************">
          </div>
          <button class="w-100 btn btn-lg sub" type="submit">Sign in</button>
        </form>
      </div>
    </body>
    <script src="/assets/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script async src="/assets/js/masonry.min.js"></script>
    <script href="/assets/fontawesome/js/all.min.js"></script>
</html>
<?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/sign-in.blade.php ENDPATH**/ ?>