
<?php $__env->startSection('content'); ?>
<div class="form-login w-100 m-auto">
  <form action="<?php echo e(route('signupmethod')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <h1 class="title-login">LOGIN</h1>
    <div class="btn-group selector">
      <a href="<?php echo e(route('login')); ?>" class="btn" aria-current="page">SIGN IN</a>
      <a href="<?php echo e(route('signup')); ?>" class="btn active">SIGN UP</a>
    </div>
    <?php if(session('error') && session('error') == 'found'): ?>
      <div class="form-group">
        <label class="error_msg">This email already exists</label>
      </div>
    <?php endif; ?>
    <div class="groupinp">
        <p>EMAIL</p>
        <input type="email" class="form-control <?php $__errorArgs = ['user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user" placeholder="YOUR EMAIL" value="<?php echo e(old('user')); ?>">
    </div>
    <div class="groupinp">
        <p>PASSWORD</p>
        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="************">
    </div>
    <div class="groupinp">
        <p>REPEAT PASSWORD</p>
        <input type="password" class="form-control <?php $__errorArgs = ['reppassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="reppassword" placeholder="************">
    </div>
    <div class="form-check">
      <input class="form-check-input" type="checkbox" name="admin" value="admin" id="flexCheckDefault">
      <label class="form-check-label" for="flexCheckDefault">
        IS ADMIN
      </label>
    </div>
    <button class="w-100 btn btn-lg sub" type="submit">Sign up</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Documentos\WEB\XAMPP\htdocs\test\resources\views/signup.blade.php ENDPATH**/ ?>